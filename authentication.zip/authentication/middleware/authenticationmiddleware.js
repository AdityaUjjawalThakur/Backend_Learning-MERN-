const jwt = require("jsonwebtoken");
const SECRET_KEY = process.env.SECRET_KEY;

// const authenticationtoken = (req, res, next) => {
//     const token = req.cookies.token;
//     console.log(token)

//     // Check if token is provided in the correct format: "Bearer <token>"
//     if (!token) {
//         return res.status(403).send("Access Denied: No Token Found");
//     }

//     // Extract the token after "Bearer " prefix
//     const tokenWithoutBearer = token.split(" ")[1];

//     // If token doesn't follow "Bearer <token>" format
//     if (!tokenWithoutBearer) {
//         return res.status(403).send("Access Denied: Invalid Token Format");
//     }

//     // Verify the token using JWT and SECRET_KEY
//     try {
//         const verified = jwt.verify(tokenWithoutBearer, SECRET_KEY);
//         console.log("Token Verified:", verified); // Log the verified user data

//         // Attach the decoded user information to the req object
//         req.user = verified;
        
//         // Continue to the next middleware/route
//         next();
//     } catch (err) {
//         console.error("Token verification failed:", err);
//         return res.status(403).send("Access Denied: Invalid or Expired Token");
//     }
// };
const authenticationtoken = (req, res, next) => {
    const token = req.cookies.token; // Now you'll find the token here
    console.log(token)

    if (!token) {
        return res.status(403).send("Access Denied: No Token Found");
    }
    const tokenWithoutBearer = token.split(" ")[1];
    if (!tokenWithoutBearer) {
        return res.status(403).send("Access Denied: Invalid Token Format");
    }

    try {
        const verified = jwt.verify(tokenWithoutBearer, SECRET_KEY);
        console.log("Token Verified:", verified);
        req.user = verified;
        next();
    } catch (err) {
        console.error("Token verification failed:", err);
        return res.status(403).send("Access Denied: Invalid or Expired Token");
    }
};

module.exports = authenticationtoken;
