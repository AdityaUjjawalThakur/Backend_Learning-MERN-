const express=require("express")
const dotnev=require("dotenv")
const bcrypt=require("bcrypt")
const cookie=require("cookie")
const cors=require("cors")
const jwt=require("jsonwebtoken")
const {body,validationResult}=require("express-validator")
const bodyparser=require("body-parser")
const app=express();
const mysql=require("mysql2")
const authenticationtoken=require("./middleware/authenticationmiddleware")
dotnev.config();
app.use(express.urlencoded({extended:true}))
app.use(express.json())
app.use(cors())
app.use(bodyparser.json())
app.set("view engine","ejs")
app.set("views","./views")
const SECRET_KEY=process.env.SECRET_KEY;
const db=mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"4nm21cs007",
  database:"register"


})
db.connect((err)=>{
    if(err)
    {
        console.error(err)
    }else{
        console.log(`sucessfully connected to database`)
    }
})

//encrypting passwords
// async function encryption(password)
// {
//     const hashedPassword=await bcrypt.hash(password,10);
//     console.log(`plain password is ${password}`)
//     console.log(`hashed password ${hashedPassword}`)
//     if(bcrypt.compare(password,hashedPassword))
//     {
//         console.log("correct match")
//     }else{
//         console.log("bhak bosdik")
//     }

// }
// encryption("aditya123")
app.get("/register",(req,res)=>{
    res.render("register")

})
app.post("/register",[body("name").trim().notEmpty().withMessage("Name can not be empty"),
    body("email").notEmpty().normalizeEmail().withMessage("Invalid Email Format"),
    body("password").notEmpty().withMessage("password Can Not Be Empty")
],async(req,res)=>{
    const validationerror=validationResult(req)
    if(!validationerror.isEmpty())
    {
        return res.json(validationerror)
    }
    console.error(validationerror)
    const {name,email,password}=req.body;
    console.log(`${name} ${email} ${password}`)
    const hashedPassword= await bcrypt.hash(password,10);//10 is salt value
    const sql="insert into user(name,email,password)values(?,?,?)"
    db.query(sql,[name,email,hashedPassword],(err,result)=>{
        if(err)
        {
            console.error(err);
            
        }else{
            res.send("Sucessfully Registered")
        }

    })


})
app.get("/login",(req,res)=>{
    res.render("login")
})
app.post("/login",async(req,res)=>{
    const{name,password}=req.body;
    const sql="select * from user where name=?"
    db.query(sql,[name],async(err,result)=>{
        if(err)
        {
            console.error(err)
        }else{
            const ismatch= await bcrypt.compare(password,result[0].password)
            if(!ismatch)
            {
                res.send("incorrect credentials")
               
            }else{
                const token=jwt.sign({username:name},SECRET_KEY,{expiresIn:"1hr"});
                console.log(token)
               res.send
               
            }
        }

    })
    

})

app.get("/login/dashboard", authenticationtoken, (req, res) => {
    res.send(`Welcome ${req.user.username}`); // Send the verified user info
});
app.listen(process.env.PORT,()=>{
    console.log(`Server Is Live At ${process.env.PORT}`)
})

// const express = require("express");
// const dotenv = require("dotenv");
// const bcrypt = require("bcrypt");
// const cors = require("cors");
// const jwt = require("jsonwebtoken");
// const { body, validationResult } = require("express-validator");
// const bodyParser = require("body-parser");
// const app = express();
// const mysql = require("mysql2");
// // const authenticationtoken = require("./middleware/authenticationmiddleware");

// dotenv.config();
// app.use(express.urlencoded({ extended: true }));
// app.use(express.json());
// app.use(cors());
// app.use(bodyParser.json());
// app.set("view engine", "ejs");
// app.set("views", "./views");
// const SECRET_KEY = process.env.SECRET_KEY;

// const db = mysql.createConnection({
//     host: "localhost",
//     user: "root",
//     password: "4nm21cs007",
//     database: "register",
// });

// db.connect((err) => {
//     if (err) {
//         console.error(err);
//     } else {
//         console.log(`Successfully connected to database`);
//     }
// });

// // ... (register route code remains the same)

// const authenticationtoken = (req, res, next) => {
//     const token = req.header("Authorization");
//     console.log(token)

//     // Check if token is provided in the correct format: "Bearer <token>"
//     if (!token) {
//         return res.status(403).send("Access Denied: No Token Found");
//     }

//     // Extract the token after "Bearer " prefix
//     const tokenWithoutBearer = token.split(" ")[1];

//     // If token doesn't follow "Bearer <token>" format
//     if (!tokenWithoutBearer) {
//         return res.status(403).send("Access Denied: Invalid Token Format");
//     }

//     // Verify the token using JWT and SECRET_KEY
//     try {
//         const verified = jwt.verify(tokenWithoutBearer, SECRET_KEY);
//         console.log("Token Verified:", verified); // Log the verified user data

//         // Attach the decoded user information to the req object
//         req.user = verified;
        
//         // Continue to the next middleware/route
//         next();
//     } catch (err) {
//         console.error("Token verification failed:", err);
//         return res.status(403).send("Access Denied: Invalid or Expired Token");
//     }
// };

// app.get("/login", (req, res) => {
//     res.render("login");
// });

// app.post("/login", async (req, res) => {
//     const { name, password } = req.body;
//     const sql = "SELECT * FROM user WHERE name = ?"; // Use SELECT * to retrieve all user data

//     db.query(sql, [name], async (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).json({ message: "Database error" }); // Handle database errors
//             return; // Important: Stop further execution
//         }

//         if (result.length === 0) {  // Check if any user with that name exists
//             return res.status(401).json({ message: "User not found" }); // Send a 401 Unauthorized
//         }

//         const user = result[0]; // Get the first user (handle multiple users with same name if needed)
//         const ismatch = await bcrypt.compare(password, user.password);

//         if (!ismatch) {
//             return res.status(401).json({ message: "Incorrect credentials" }); // 401 for incorrect password
//         } else {
//             const token = jwt.sign({ username: name }, SECRET_KEY, { expiresIn: "1hr" });
//             console.log(token);
//             res.header("Authorization", `Bearer ${token}`).json({
//                 message: "Successfully Logged In",
//                 token: token,
//             });
//         }
//     });
// });


// app.get("/login/dashboard", authenticationtoken, (req, res) => {
//     res.send(`Welcome ${req.user.username}`);
// });

// app.listen(process.env.PORT, () => {
//     console.log(`Server Is Live At ${process.env.PORT}`);
// });